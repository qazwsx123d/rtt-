#ifndef SG90_H
#define SG90_H
#include "gd32f5xx.h"

void SG90_Init(void);

void SG90_SetAngle(uint16_t angle);

#endif

