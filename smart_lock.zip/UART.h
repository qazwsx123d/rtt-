#ifndef _UART_H_
#define _UART_H_
#include "gd32f5xx.h"
void UART_Init();
void UART3_Init();
#endif
		