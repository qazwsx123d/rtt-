
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'GD32F527I_EVAL' 
 * Target:  'GD32F527I_EVAL' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H



#endif /* RTE_COMPONENTS_H */
