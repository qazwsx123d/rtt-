#ifndef _LED_H_
#define _LED_H_
#include "gd32f5xx.h"
void LED_Init();
void LED_On();
void LED_off();
void LED4_ON();
void LED4_OFF();
#endif
